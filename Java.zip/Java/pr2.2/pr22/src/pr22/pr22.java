package pr22;

public class pr22 {

	public static void main(String[] args) {
		System.out.println("Java say:");
		System.out.println("FIO: BBorisDM");
		System.out.println("Group: POKS32");
		System.out.println("hightSchool: RKSI");
	}

}
