/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pr5;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class Pr5 {

    /**
     
     */
    public static final int LINES = 10;  /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Задание 1");
        double[] myArray = {11, 5.6, 11.2, 10.9}; 
        double max = Double.MIN_VALUE;
        
        for(int i = 0; i < myArray.length; i++){
            max = Math.max(max, myArray[i]);
        }
        System.out.println("Максимальный элемент массива c помощью Math.max: " + max);
    
        double max2 = myArray[0];
        for (int i = 1; i < myArray.length; i++) {
            if (myArray[i] > max2){
                max2 = myArray[i];
            }
        }
        System.out.println("Максимальный элемент массива c помощью цикла: " + max2);
        
        System.out.println("\n"+ "\n"+ "\n"+ "Задание 2");
        try{
        Scanner input = new Scanner(System.in); 
    System.out.println("Введите количество элементов массива: ");
    int size = input.nextInt(); 
    int array[] = new int[size]; 
    System.out.println("Вводите элементы массива:");
    for (int i = 0; i < size; i++) {
        array[i] = input.nextInt(); 
    }
    System.out.print ("Ваш массив:");
    for (int i = 0; i < size; i++) {
        System.out.print (" " + array[i]); 
    }
    System.out.println();
        double sum=0;
    for(int i=0; i < array.length; i++) {
        sum=sum+ array[i];
    }
    System.out.println("Сумма элементов массива: " + sum);
    
     for(int i=0; i < array.length; i++) {
         array[i] = array[i] * 2;
     }
     
     System.out.print ("Ваш массив, но каждый элемент вдвое больше:");
    for (int i = 0; i < size; i++) {
        System.out.print (" " + array[i]); 
    }
    System.out.println();
        
        
    System.out.println("\n"+ "\n"+ "\n"+ "Задание 4");
        double min = array[0];
        for (int i = 1; i < array.length; i++) {
            if (array[i] < min){
                min = array[i];
            }
        }
        double max3 = array[0];
        for (int i = 1; i < myArray.length; i++) {
            if (myArray[i] > max3){
                max3 = myArray[i];
            }
        }
        System.out.println("Наименьший элемент массива: " + min/2);
        System.out.println("Наибольший элемент массива: " + max2/2);
        int razn;
        razn = (int) (max2/2 - min/2);
        System.out.println("Разность наибольшенго и наименьшего элемента массива: " + razn);
        
        System.out.println("\n"+ "\n"+ "\n"+"Задание Треугольник Паскаля");
        int[][] p = new int[LINES][];
        p[0] = new int[1];
        System.out.println(p[0][0] = 1);
        p[1] = new int[2];
        p[1][0] = p[1][1] = 1;
        System.out.println(p[1][0]+"\t"+p[1][1]);
        for (int i = 2; i < LINES; i++)
        {
            p[i] = new int[i+1];
            System.out.print((p[i][0] = 1)+ "\t");
            for (int j = 1; j < i; j++)
            {
               System.out.print((p[i][j] = p[i-1][j-1] + p[i-1][j]) + "\t");
            }
            System.out.println(p[i][i] = 1);
            
    }
        }
        catch(Exception e){
            System.out.println("Допущена ошибка");
        }
    }
}
