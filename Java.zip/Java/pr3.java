import java.until.Scanner;
public class Scanner {
	public static void main (String [] args) {
		Scanner in = new Scanner(System.in);
		System.out.print("Enter name: ");
		String name = in.nextLine();
		System.out.print("Enter age: ");
		int age = in.nextInt();
		System.out.println("Your name: " + name + "   Your age: " + age);
	}
}